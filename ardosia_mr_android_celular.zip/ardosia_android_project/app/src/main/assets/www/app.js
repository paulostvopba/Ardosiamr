const KEY="ardosia-mr-v1";
const empty={services:[],maintenance:[],purchases:[],quotes:[],urgencies:[],stock:[],movements:[],team:[]};
let db={...empty,...JSON.parse(localStorage.getItem(KEY)||"{}")};
const $=s=>document.querySelector(s);
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const today=new Date().toISOString().slice(0,10);
$("#today").textContent=new Date().toLocaleDateString("pt-BR",{day:"2-digit",month:"short",year:"numeric"});
document.querySelectorAll('input[type=date]').forEach(x=>{if(!x.value)x.value=today});
function save(){localStorage.setItem(KEY,JSON.stringify(db));render()}
function card(title,lines=[],tag=""){return `<article class="item"><h3>${esc(title)}</h3>${lines.map(x=>`<p>${esc(x)}</p>`).join("")}${tag?`<span class="pill">${esc(tag)}</span>`:""}</article>`}
function render(){
 $("#countServices").textContent=db.services.length;
 $("#countUrgencies").textContent=db.urgencies.filter(x=>!x.closed).length;
 $("#countStock").textContent=db.stock.length;
 $("#servicesList").innerHTML=db.services.slice().reverse().map(x=>card(x.name,[`${x.technician} · ${x.date}`,x.description,x.photos?.length?`${x.photos.length} foto(s) anexada(s)`:"Sem fotos"])).join("")||'<div class="empty">Nenhum serviço registrado.</div>';
 $("#maintenanceList").innerHTML=db.maintenance.slice().sort((a,b)=>a.date.localeCompare(b.date)).map(x=>card(x.name,[`${x.date} · ${x.technician||"Sem responsável"}`,x.description],x.type)).join("")||'<div class="empty">Nenhuma manutenção programada.</div>';
 $("#purchasesList").innerHTML=db.purchases.slice().reverse().map(x=>card(x.name,[`Qtd.: ${x.quantity} · Fornecedor: ${x.supplier||"Não informado"}`,`R$ ${Number(x.value||0).toFixed(2)} · ${x.date}`],x.status)).join("")||'<div class="empty">Nenhuma compra registrada.</div>';
 $("#quotesList").innerHTML=db.quotes.slice().reverse().map(x=>card(x.name,[`Solicitante: ${x.requester||"Não informado"}`,`Materiais: R$ ${x.materials.toFixed(2)} · Mão de obra: R$ ${x.labor.toFixed(2)}`,`Total: R$ ${(x.materials+x.labor).toFixed(2)}`],x.status)).join("")||'<div class="empty">Nenhum orçamento registrado.</div>';
 $("#urgenciesList").innerHTML=db.urgencies.slice().reverse().map((x,i)=>`<article class="item"><h3>${esc(x.name)}</h3><p>${esc(x.location)} · ${esc(x.technician||"Sem responsável")}</p><span class="pill ${x.priority==="Crítica"?"red":x.priority==="Alta"?"yellow":""}">${esc(x.priority)}</span> ${x.closed?'<span class="pill">Encerrada</span>':`<button class="secondary" data-close="${db.urgencies.length-1-i}">Encerrar</button>`}</article>`).join("")||'<div class="empty">Nenhuma urgência registrada.</div>';
 $("#stockList").innerHTML=db.stock.map(x=>card(x.name,[`Disponível: ${x.quantity} unidade(s)`,`Mínimo: ${x.minimum}`],x.quantity<=x.minimum?"Estoque baixo":"Disponível")).join("")||'<div class="empty">Estoque ainda não cadastrado.</div>';
 $("#movementList").innerHTML=db.movements.slice().reverse().slice(0,15).map(x=>`<p>${esc(x.type)} · ${esc(x.name)} · ${x.quantity} un. · ${esc(x.date)}</p>`).join("")||"Nenhuma movimentação registrada.";
 $("#teamList").innerHTML=db.team.map(x=>card(x.name,[`Usuário: ${x.username}`],x.role)).join("")||'<div class="empty">Nenhum funcionário adicionado.</div>';
 $("#recentList").innerHTML=[...db.services.map(x=>({title:x.name,sub:`Serviço · ${x.date}`})),...db.maintenance.map(x=>({title:x.name,sub:`Manutenção · ${x.date}`}))].slice(-5).reverse().map(x=>card(x.title,[x.sub])).join("")||'<div class="empty">Nenhum registro cadastrado neste aparelho.</div>';
}
function values(form){return Object.fromEntries(new FormData(form).entries())}
function bind(id,fn){$(id).addEventListener("submit",async e=>{e.preventDefault();const f=e.currentTarget;await fn(values(f),f);f.reset();f.querySelectorAll('input[type=date]').forEach(x=>x.value=today);save()})}
bind("#serviceForm",async(v,f)=>{const files=[...f.elements.photos.files];const photos=[];for(const file of files.slice(0,4)){photos.push({name:file.name,type:file.type,size:file.size})}db.services.push({...v,photos})});
bind("#maintenanceForm",v=>db.maintenance.push(v));
bind("#purchaseForm",v=>db.purchases.push({...v,quantity:Number(v.quantity),value:Number(v.value||0)}));
bind("#quoteForm",v=>db.quotes.push({...v,materials:Number(v.materials||0),labor:Number(v.labor||0)}));
bind("#urgencyForm",v=>db.urgencies.push({...v,closed:false}));
bind("#teamForm",v=>db.team.push(v));
bind("#stockForm",v=>{
 const q=Number(v.quantity);let item=db.stock.find(x=>x.name.toLowerCase()===v.name.trim().toLowerCase());
 if(v.movement==="Saída"&&(!item||item.quantity<q)){alert("Estoque insuficiente para esta saída.");return}
 if(!item){item={name:v.name.trim(),quantity:0,minimum:Number(v.minimum||0)};db.stock.push(item)}
 item.quantity+=v.movement==="Entrada"?q:-q;item.minimum=Number(v.minimum||item.minimum);
 db.movements.push({name:item.name,quantity:q,type:v.movement,date:today});
});
document.addEventListener("click",e=>{
 const tab=e.target.closest("[data-page]");if(tab)go(tab.dataset.page);
 const quick=e.target.closest("[data-go]");if(quick)go(quick.dataset.go);
 const close=e.target.closest("[data-close]");if(close){db.urgencies[Number(close.dataset.close)].closed=true;save()}
});
function go(page){document.querySelectorAll(".page").forEach(x=>x.classList.toggle("active",x.id===page));document.querySelectorAll(".tab").forEach(x=>x.classList.toggle("active",x.dataset.page===page));window.scrollTo({top:0,behavior:"smooth"})}
$("#printReport").onclick=()=>{const w=window.open("","_blank");if(!w){alert("Permita abrir a janela de impressão.");return}const data={servicos:db.services,manutencoes:db.maintenance,compras:db.purchases,orcamentos:db.quotes,urgencias:db.urgencies,estoque:db.stock,movimentacoes:db.movements,equipe:db.team};w.document.write(`<html><head><title>Relatório ARDOSIA MR</title><style>body{font:14px Arial;padding:28px;color:#17243a}h1{color:#1554a3}h2{font-size:17px;margin-top:22px}pre{white-space:pre-wrap;font:12px Arial}</style></head><body><h1>ARDOSIA MR</h1><p>Relatório gerado em ${new Date().toLocaleString("pt-BR")}</p>${Object.entries(data).map(([k,v])=>`<h2>${k.toUpperCase()} (${v.length})</h2><pre>${JSON.stringify(v,null,2).replace(/[&<>]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;"}[c]))}</pre>`).join("")}</body></html>`);w.document.close();w.print()};
$("#exportData").onclick=()=>{const blob=new Blob([JSON.stringify(db,null,2)],{type:"application/json"});const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="ardosia-mr-dados.json";a.click();URL.revokeObjectURL(a.href)};
$("#clearData").onclick=()=>{if(confirm("Apagar todos os registros salvos neste aparelho? Esta ação não pode ser desfeita.")){db=structuredClone(empty);save()}};
render();
if("serviceWorker" in navigator && location.protocol.startsWith("http"))navigator.serviceWorker.register("./sw.js").catch(()=>{});
